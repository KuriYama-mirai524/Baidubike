# 及其简陋的百度插件
![V@A9E1N0GJM9`NZ_GLYMFZF](https://user-images.githubusercontent.com/93362741/153986127-919129ec-6787-4221-81b9-db489559ef54.png)

 
 需要用到mirai-http,在这之前请先阅读
 
 [mirai-http官方文档](https://github.com/project-mirai/mirai-api-http)
 
 
 
 
 
For Windows:
使用前请先安装Chrome，并且pip install selenium库

windows用户请[查看](https://blog.csdn.net/shykevin/article/details/108802053?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522164489415616780271548606%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=164489415616780271548606&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_positive~default-1-108802053.first_rank_v2_pc_rank_v29&utm_term=selenium%E5%AE%89%E8%A3%85chrome%E9%A9%B1%E5%8A%A8&spm=1018.2226.3001.4187)









For Linux: （安装较麻烦）
1，将两个py文件(main.py和spider.py下载到你的linux服务器。
2, [安装selenium依赖](https://blog.csdn.net/qq_41137110/article/details/109499720?ops_request_misc=&request_id=&biz_id=102&utm_term=linux%E5%AE%89%E8%A3%85selenium&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-5-109499720.first_rank_v2_pc_rank_v29&spm=1018.2226.3001.4187)


2，

